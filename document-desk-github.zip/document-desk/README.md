# Document Desk

Single-file browser tool for PDF/GST paperwork — **V2.1.2**.

## Features
- **Splitter** — split one bundled GST PDF into party-wise invoice / credit note / ledger PDFs (ZIP download)
- **Smart Convert** — images to PDF (page size, 2-in-1 landscape, DPI, sharpen)
- **Smart Edit** — reorder / rotate / delete pages, merge PDFs, annotate, visual cover, sign
- **Smart Excel** — read purchase bills into Excel-ready data (local text read first, optional AI mode)

## How to run
Open `index.html` in a browser (Chrome recommended), or host it with GitHub Pages.
Needs internet for the CDN libraries (pdf.js, pdf-lib, JSZip, SheetJS).

## Privacy
Split, Convert and Edit run fully in the browser — no upload.
Smart Excel's optional AI mode sends a bill page to the provider (Gemini or Claude) whose API key you add in Settings.
API keys are kept in tab memory unless "remember" is ticked.

## Note
Visual cover in Smart Edit is **not** certified secure redaction.

Built by Farhan — farhanahmadx11@gmail.com
